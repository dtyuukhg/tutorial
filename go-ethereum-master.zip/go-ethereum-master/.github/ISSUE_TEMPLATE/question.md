---
name: Ask a question
about: Something is unclear
title: ''
labels: 'type:docs'
assignees: ''
---

This should only be used in very rare cases e.g. if you are not 100% sure if something is a bug or asking a question that leads to improving the documentation. For general questions please use [discord](https://discord.gg/nthXNEv) or the Ethereum stack exchange at https://ethereum.stackexchange.com.
